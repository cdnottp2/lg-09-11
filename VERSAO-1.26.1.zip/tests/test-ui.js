/* Teste de fumaça da interface em jsdom: login -> Início -> listas -> player -> detalhe -> série -> busca -> favoritos
   -> continuar assistindo -> configurações -> demo. A rede passa pelo proxy real (PalmServiceBridge simulado). */
var path = require('path');
var assert = require('assert');
var jsdom = require('jsdom');
var mock = require('./mock-server.js');
var proxyLib = require('../services/com.rodrigo.iptv.service/proxy.js');

var api = mock.create(), px = proxyLib.create('tok');
function listen(s) { return new Promise(function (r) { s.listen(0, '127.0.0.1', r); }); }
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

var syncKV = {}, syncSrv = null;
// servidor de sincronização falso: o próprio Worker, com KV em memória, atrás de um servidor HTTP local
function startSync() {
  return import('../worker/sync-worker.mjs').then(function (m) {
    var env = { SYNC: { get: async function (k) { return Object.prototype.hasOwnProperty.call(syncKV, k) ? syncKV[k] : null; }, put: async function (k, v) { syncKV[k] = v; } } };
    syncSrv = require('http').createServer(function (req, res) {
      var chunks = [];
      req.on('data', function (c) { chunks.push(c); });
      req.on('end', function () {
        var body = Buffer.concat(chunks).toString('utf8'), noBody = req.method === 'GET' || req.method === 'HEAD';
        m.default.fetch(new Request('http://sync.local' + req.url, { method: req.method, body: noBody ? undefined : body }), env).then(function (r) {
          return r.text().then(function (txt) {
            var hd = {}; r.headers.forEach(function (v, k) { hd[k] = v; });
            res.writeHead(r.status, hd); res.end(txt);
          });
        });
      });
    });
    return listen(syncSrv);
  });
}

Promise.all([listen(api), listen(px), startSync()]).then(function () {
  var base = 'http://127.0.0.1:' + api.address().port, pport = px.address().port;
  var errors = [];
  var vc = new jsdom.VirtualConsole();
  vc.on('jsdomError', function (e) { if (!/mpegts|hls|Not implemented/i.test(String(e.message))) { errors.push(e.message); } });

  return jsdom.JSDOM.fromFile(path.join(__dirname, '../app/index.html'), {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse: function (w) {
      w.Element.prototype.getBoundingClientRect = function () { return { left: 0, top: 0, right: 100, bottom: 50, width: 100, height: 50 }; };
      w.HTMLMediaElement.prototype.play = function () { return Promise.resolve(); };
      // jsdom com file:// tem origem opaca (sem localStorage): usa um armazenamento em memória
      var mem = {};
      Object.defineProperty(w, 'localStorage', { configurable: true, value: {
        getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
        setItem: function (k, v) { mem[k] = String(v); },
        removeItem: function (k) { delete mem[k]; }
      } });
      w.HTMLMediaElement.prototype.pause = function () {};
      w.HTMLMediaElement.prototype.load = function () {};
      w.PalmServiceBridge = function () {
        var self = this;
        this.call = function () { setTimeout(function () { self.onservicecallback(JSON.stringify({ returnValue: true, port: pport, token: 'tok' })); }, 0); };
      };
    }
  }).then(function (dom) {
    var w = dom.window, d = w.document;
    var $ = function (s) { return d.querySelector(s); }, $$ = function (s) { return [].slice.call(d.querySelectorAll(s)); };
    function key(code) { d.dispatchEvent(new w.KeyboardEvent('keydown', { keyCode: code, bubbles: true, cancelable: true })); }
    // navega pelo menu inicial: volta ao menu (se preciso) e abre a seção
    function go(sec) {
      while (!$('.hubtab[data-sec]') && $('.backbtn')) { $('.backbtn').click(); } // a busca de seção volta primeiro à seção, depois ao menu
      if (sec === 'home') { return; }
      if (sec === 'settings') { $('.menubtn').click(); $('.drawer-settings').click(); return; } // Configurações ficam no menu lateral
      $('[data-sec="' + sec + '"]').click();
    }
    function waitFor(fn, label) {
      var t0 = Date.now();
      return (function loop() {
        var v; try { v = fn(); } catch (e) { v = false; }
        if (v) { return Promise.resolve(v); }
        if (Date.now() - t0 > 6000) { return Promise.reject(new Error('timeout: ' + label + ' | detail: ' + ($('#detail') ? $('#detail').textContent.slice(0, 300) : ''))); }
        return sleep(25).then(loop);
      })();
    }
    var step = function (n) { console.log('  ok   ' + n); };
    var video = $('#video'), vt = 0, vd = NaN;
    Object.defineProperty(video, 'currentTime', { get: function () { return vt; }, set: function (v) { vt = v; }, configurable: true });
    Object.defineProperty(video, 'duration', { get: function () { return vd; }, configurable: true });

    return waitFor(function () { return $('.login') && w.Weather; }, 'login').then(function () {
      // clima falso (a rede real não é usada nos testes)
      var wxCalls = [];
      w.Weather.init(function (u) {
        wxCalls.push(u);
        if (/geocoding/.test(u)) { return Promise.resolve(JSON.stringify({ results: [{ name: 'Campinas', admin1: 'São Paulo', country_code: 'BR', latitude: -22.9, longitude: -47.06 }] })); }
        return Promise.resolve(JSON.stringify({ current: { temperature_2m: 24.4, apparent_temperature: 25, weather_code: 2, is_day: 1 },
          daily: { temperature_2m_min: [17.2], temperature_2m_max: [28.6] } }));
      });
      w.Sports.setBase(base + '/espn');   // placares simulados (a Início já pede os jogos de hoje)
      var inputs = $$('.login input');
      assert.strictEqual(inputs.length, 3);
      inputs[0].value = base; inputs[1].value = 'joao'; inputs[2].value = 'errada';
      $('.btn.primary').click();
      return waitFor(function () { return /inválidos/.test($('.err') ? $('.err').textContent : ''); }, 'erro de login');
    }).then(function () {
      var inputs = $$('.login input');
      assert.deepStrictEqual(inputs.map(function (i) { return i.value; }), [base, 'joao', 'errada'], 'campos preservados');
      step('erro de login mantém os dados nos campos');
      inputs[2].value = 'segredo';
      $('.btn.primary').click();
      return waitFor(function () { return $$('.hubtab').length === 4; }, 'menu inicial');
    }).then(function () {
      assert.deepStrictEqual($$('.hubtab').map(function (e) { return e.textContent; }), ['TV ao vivo', 'Filmes', 'Séries', 'Esportes']);
      assert.ok($('.hubtab.focus'), 'foco no primeiro item do menu');
      assert.ok(!$('.side'), 'sem barra lateral');
      assert.ok(!$('.hub-links') && !$$('.hub-links .btn').length, 'sem botões de atalho embaixo (Buscar/Configurações vão no topo)');
      assert.ok(!$$('.hrow-title').some(function (t) { return t.textContent === 'Favoritos'; }), 'sem favoritos: a fileira não aparece');
      var hdKids = [].slice.call($('.sechead').children).map(function (c) { return c.className.replace(/\bf\b/, '').replace(/\bfocus\b/, '').replace(/\s+/g, ' ').trim(); });
      assert.deepStrictEqual(hdKids, ['iconbtn menubtn', 'brand', 'avatar'], 'topo: menu à esquerda, nome no centro, perfil à direita: ' + hdKids.join(' | '));
      assert.strictEqual($('.sechead .brand').textContent, 'MASTER IPTV', 'nome do app no centro');
      assert.ok(!$('.sechead .wx') && !$('.sechead .clock') && !$('.sechead .usub'), 'clima/relógio/validade não ficam no topo');
      assert.ok($('.drawer').classList.contains('hidden'), 'menu lateral começa fechado');
      assert.ok($('.drawer .wx') && $('.drawer .clock') && $('.drawer .drawer-settings'), 'clima, relógio e Configurações dentro do menu lateral');
      step('menu inicial: TV ao vivo / Filmes / Séries');
      return waitFor(function () { return $('.wx-t') && /24°/.test($('.wx-t').textContent); }, 'clima');
    }).then(function () {
      assert.ok(/Taubaté/.test($('.wx-c').textContent), 'cidade padrão');
      assert.ok(/17° \/ 29°/.test($('.wx-r').textContent) && /Parcialmente/.test($('.wx-r').textContent), $('.wx-r').textContent);
      $('.menubtn').click();
      assert.ok(!$('.drawer').classList.contains('hidden'), 'hambúrguer abre o menu lateral');
      assert.ok($('.drawer-settings').classList.contains('focus'), 'foco em Configurações dentro do menu');
      key(461);
      assert.ok($('.drawer').classList.contains('hidden'), 'Voltar fecha o menu lateral (sem sair do app)');
      assert.ok($('.menubtn').classList.contains('focus'), 'foco volta ao hambúrguer');
      step('menu lateral: abre, mostra clima/Configurações e fecha com Voltar');
      step('clima na home (24°, mín/máx, cidade)');
      go('live');
      return waitFor(function () { return $$('.cat').length === 4 && $$('.row').length === 1; }, 'ao vivo');
    }).then(function () {
      assert.strictEqual($$('.card').length, 0, 'ao vivo só tem canais');
      return waitFor(function () { return /Jornal da Noite/.test($('.row .epg').textContent); }, 'epg na lista');
    }).then(function () {
      assert.ok($('.row .epgbar.on'), 'barra de progresso do programa');
      assert.ok(/^\d\d:\d\d–\d\d:\d\d  Jornal da Noite/.test($('.row .epg').textContent), 'horário início–fim: ' + $('.row .epg').textContent);
      assert.ok(/^A seguir  \d\d:\d\d  Cinema da Madrugada/.test($('.row .epgnext').textContent), 'próximo programa: ' + $('.row .epgnext').textContent);
      assert.ok($$('.cat .ct').every(function (e) { return !/^Canais\s*\|/.test(e.textContent); }), 'categorias sem o prefixo "Canais |"');
      assert.ok($$('.cat .ct').some(function (e) { return e.textContent === '⚽ Esportes'; }), 'nome limpo da categoria: ' + $$('.cat .ct').map(function (e) { return e.textContent; }).join(' | '));
      step('EPG do canal aparece na lista (horário + próximo) e categorias sem prefixo');
      assert.ok(/TV ao vivo/.test($('.sectitle').textContent));
      $$('.cat')[2].click();
      return waitFor(function () { return $$('.row').length === 2; }, 'cat esportes');
    }).then(function () {
      step('categorias ao vivo');
      $$('.cat')[3].click();
      return waitFor(function () { return $$('.row .epg.none').length >= 1; }, 'canal sem EPG');
    }).then(function () {
      assert.strictEqual($('.row .epg.none').textContent, 'Sem programação', 'canal sem EPG mostra texto discreto');
      step('canal sem EPG: "Sem programação"');
      $$('.cat')[2].click();
      return waitFor(function () { return $$('.row').length === 2; }, 'volta a esportes');
    }).then(function () {
      $$('.row')[0].click();
      return waitFor(function () { return !$('#player').classList.contains('hidden') && $('#video').getAttribute('src'); }, 'player live');
    }).then(function () {
      assert.ok(/102\.m3u8$/.test($('#video').getAttribute('src')));
      key(38);
      return waitFor(function () { return /103\.m3u8$/.test($('#video').getAttribute('src') || ''); }, 'zap');
    }).then(function () {
      step('player ao vivo + troca de canal');
      // áudio e legenda: faixas expostas pelo player (simuladas) + tecla verde
      var vid = $('#video'), aud = [{ label: '', language: 'por', enabled: true }, { label: 'Dolby 5.1', language: 'eng', enabled: false }];
      Object.defineProperty(vid, 'audioTracks', { value: aud, configurable: true });
      var tt = vid.textTracks;
      vid.dispatchEvent(new w.Event('loadedmetadata'));
      key(404);
      assert.ok(!$('#tracks').classList.contains('hidden'), 'painel abre com a tecla verde');
      assert.deepStrictEqual($$('#tracks .topt .t-lbl').map(function (e) { return e.textContent; }), ['Português', 'Inglês · Dolby 5.1']);
      assert.ok(/não traz legendas/.test($('#tracks').textContent), 'sem legendas: aviso');
      $$('#tracks .topt')[1].click();
      assert.deepStrictEqual(aud.map(function (t) { return t.enabled; }), [false, true], 'troca o áudio');
      key(27);
      assert.ok($('#tracks').classList.contains('hidden') && !$('#player').classList.contains('hidden'), 'Voltar fecha só o painel');
      step('áudio e legenda: painel, troca de faixa, Voltar fecha só o painel');
      key(27);
      assert.ok(!$('#player').classList.contains('hidden') && $('#player').classList.contains('mini'), 'Voltar minimiza o player');
      assert.ok(d.body.classList.contains('mini-on') && !$('#app').classList.contains('hidden'), 'lista visível com o mini player');
      // controle sem botões coloridos (Android TV): os botões do mini player entram na navegação do direcional
      assert.ok(w.Nav.all().indexOf($('#mini-open')) >= 0 && w.Nav.all().indexOf($('#mini-x')) >= 0, 'botões do mini player são navegáveis');
      w.Nav.focus($('#mini-open'));
      assert.strictEqual(w.Nav.current(), $('#mini-open'), 'foco no botão Ampliar');
      key(13);
      assert.ok(!$('#player').classList.contains('mini'), 'OK em "Ampliar" volta ao player em tela cheia');
      key(27);
      w.Nav.focus($('#mini-x'));
      key(13);
      assert.ok($('#player').classList.contains('hidden'), 'OK no X fecha o mini player');
      assert.ok(w.Nav.current(), 'o foco volta para a lista');
      step('mini player alcançável só com o direcional (Ampliar e Fechar)');
      go('live');
      return waitFor(function () { return $$('.row').length > 0; }, 'canais de novo').then(function () {
        $$('.row')[0].click();
        return waitFor(function () { return !$('#player').classList.contains('hidden'); }, 'player de novo');
      });
    }).then(function () {
      key(27);
      key(405);
      assert.ok(!$('#player').classList.contains('mini'), 'Amarelo amplia');
      key(27); key(406);
      assert.ok($('#player').classList.contains('hidden') && !$('#player').classList.contains('mini'), 'Azul fecha o mini player');
      go('movie');
      return waitFor(function () { return $$('.card').length === 1; }, 'filmes');
    }).then(function () {
      // TMDB simulado: elenco do filme e filmografia do ator
      w.localStorage.setItem('iptv.tmdbkey', JSON.stringify('k'));
      w.Tmdb.findId = function () { return Promise.resolve(77); };
      w.Tmdb.credits = function () { return Promise.resolve([{ id: 9, n: 'Ana Atriz', c: 'Maria', p: '' }, { id: 10, n: 'Beto Ator', c: 'Zé', p: '' }]); };
      w.Tmdb.person = function () { return Promise.resolve([{ t: 'Filme Teste', o: '', y: 0, k: 'movie' }, { t: 'Nao Existe', o: '', y: 0, k: 'movie' }]); };
      $$('.card')[0].click();
      return waitFor(function () { return !$('#detail').classList.contains('hidden') && /Assistir/.test($('#detail .btn.primary').textContent); }, 'detalhe filme');
    }).then(function () {
      return waitFor(function () { return /Um filme de teste/.test($('#detail .dplot').textContent); }, 'plot');
    }).then(function () {
      return waitFor(function () { return $$('#detail .cast').length === 2; }, 'elenco');
    }).then(function () {
      assert.ok(/Ana Atriz/.test($('#detail .cast').textContent) && /Maria/.test($('#detail .cast').textContent));
      $$('#detail .cast')[0].click();
      return waitFor(function () { return $$('#detail .agrid .card').length === 1; }, 'filmografia do ator');
    }).then(function () {
      assert.ok(/Ana Atriz/.test($('#detail .dtitle').textContent));
      $$('#detail .agrid .card')[0].click();
      return waitFor(function () { return $('#detail .dtitle') && /Filme Teste/.test($('#detail .dtitle').textContent) && /Assistir/.test($('#detail .btn.primary').textContent); }, 'volta ao filme pelo ator');
    }).then(function () {
      key(27); // volta para a página do ator
      assert.ok(/Ana Atriz/.test($('#detail .dtitle').textContent), 'Voltar volta ao ator');
      key(27); // volta para o filme
      assert.ok(/Filme Teste/.test($('#detail .dtitle').textContent), 'Voltar volta ao filme');
      assert.ok(!$('#detail').classList.contains('hidden'));
      step('elenco + filmografia do ator');
      step('filmes + detalhe com sinopse');
      $('#detail .btn.primary').click();
      assert.ok(/501\.mkv$/.test($('#video').getAttribute('src')));
      vd = 3600; vt = 600; // simula 10 min assistidos de 1h
      key(27); assert.ok($("#player").classList.contains("mini"), "filme: Voltar minimiza"); key(406);
      assert.ok($('#player').classList.contains('hidden'));
      assert.ok(!$('#detail').classList.contains('hidden'), 'volta ao detalhe');
      assert.ok(/Continuar/.test($('#detail .btn.primary') ? $('#detail').textContent : ''), 'botão vira Continuar');
      key(27);
      assert.ok($('#detail').classList.contains('hidden'));
      go('series');
      return waitFor(function () { return $$('.card').length === 1; }, 'series');
    }).then(function () {
      $$('.card')[0].click();
      return waitFor(function () { return $$('#detail .chip').length === 2 && $$('#detail .ep').length === 2; }, 'episodios');
    }).then(function () {
      assert.deepStrictEqual($$('#detail .ep .en').map(function (e) { return e.textContent; }), ['E1', 'E2']);
      $$('#detail .ep')[0].click();
      assert.ok(/7001\.mp4$/.test($('#video').getAttribute('src')));
      step('séries -> temporadas -> episódio');
      // episódios: menu de baixo com anterior/próximo, e CH+/CH- (sem botões coloridos)
      var vsrc = function () { return $('#video').getAttribute('src'); };
      vt = 0; vd = NaN;   // sem duração: trocar de episódio não grava ponto de "continuar assistindo" neste teste
      assert.ok($('#osd-prevep').classList.contains('hidden') && !$('#osd-nextep').classList.contains('hidden'), 'primeiro episódio: só "próximo"');
      assert.ok(/E2/.test($('#osd-nextep').textContent), 'botão diz qual é o próximo: ' + $('#osd-nextep').textContent);
      $('#osd').classList.add('hidden');
      key(40);
      assert.ok($('#osd-tracks').classList.contains('focus'), 'baixo: menu com Áudio e legenda destacado');
      key(39);
      assert.ok($('#osd-nextep').classList.contains('focus') && !$('#osd-tracks').classList.contains('focus'), '→ move para "Próximo episódio"');
      key(13);
      assert.ok(/7002\.mp4$/.test(vsrc()), 'OK em "Próximo episódio" toca o E2: ' + vsrc());
      assert.ok(!$('#osd-prevep').classList.contains('hidden') && /E1/.test($('#osd-prevep').textContent), 'agora aparece "Anterior"');
      key(33);
      assert.ok(/7101\.mkv$/.test(vsrc()) && $('#osd-nextep').classList.contains('hidden'), 'CH+ avança (T2 E1) e some o "próximo" no último');
      key(34);
      key(34);
      assert.ok(/7001\.mp4$/.test(vsrc()), 'CH- volta: ' + vsrc());
      key(34);
      assert.ok(/7001\.mp4$/.test(vsrc()), 'no primeiro não recua');
      step('séries: próximo/anterior episódio (menu e CH+/CH-)');
      vd = 2700; vt = 10;
      $('#video').dispatchEvent(new w.Event('timeupdate'));
      assert.ok(!$('#skip-intro') && !$('#osd-top #osd-tracks') && !$('.osd-top #osd-tracks'), 'sem "Pular introdução" e sem o botão de áudio no topo');
      assert.ok($('.osd-info #osd-tracks'), '"Áudio e legenda" fica no menu de baixo');
      // cima e baixo abrem o menu inferior com "Áudio e legenda" destacado; OK abre o painel
      $('#osd').classList.add('hidden');
      key(40);
      assert.ok(!$('#osd').classList.contains('hidden') && $('#osd-tracks').classList.contains('focus'), 'baixo abre o menu com Áudio e legenda');
      $('#osd').classList.add('hidden');
      key(38);
      assert.ok(!$('#osd').classList.contains('hidden') && $('#osd-tracks').classList.contains('focus') && $('#tracks').classList.contains('hidden'), 'cima também abre o menu (sem abrir o painel direto)');
      key(13);
      assert.ok(!$('#tracks').classList.contains('hidden'), 'OK no menu abre áudio e legenda');
      key(27);
      key(39);
      assert.ok(!$('#osd-tracks').classList.contains('focus'), 'outra tecla tira o destaque do menu');
      var was = vt; key(13);
      assert.ok($('#tracks').classList.contains('hidden'), 'OK sem o menu aberto só pausa/continua');
      step('menu inferior: cima/baixo -> Áudio e legenda; sem Pular introdução');
      vt = 0; vd = NaN;
      key(27); key(27);
      go('home');
      return waitFor(function () { return $$('.hrow-title').map(function (e) { return e.textContent; }).indexOf('Continuar assistindo') >= 0; }, 'continuar assistindo');
    }).then(function () {
      assert.ok($('.hubtab'), 'voltou ao menu');
      var w0 = $('.lcard .pbar .fill').getAttribute('style');
      assert.ok(/width:17%/.test(w0), 'barra de progresso ~17%: ' + w0);
      assert.ok(/50 min restantes/.test($('.lcard .ls').textContent), $('.lcard .ls').textContent);
      assert.ok($$('.hrow-title').map(function (e) { return e.textContent; }).indexOf('Canais recentes') >= 0, 'canais recentes');
      step('menu: Continuar assistindo (progresso) + canais recentes');
      $('.lcard').click(); // Continuar
      assert.ok(/501\.mkv$/.test($('#video').getAttribute('src')), 'src: ' + $('#video').getAttribute('src') + ' | ' + $('.lcard').textContent);
      vt = 0; vd = NaN;
      key(27);
      go('live'); // a lupa saiu da home: a busca agora fica dentro de cada seção
      $$('.sechead .btn').filter(function (b) { return !b.classList.contains('backbtn'); })[0].click();
      return waitFor(function () { return $('#q'); }, 'busca');
    }).then(function () {
      $('#q').value = 'esporte';
      $('#q').focus();
      key(13);
      return waitFor(function () { return $$('.card').length === 2; }, 'resultados');
    }).then(function () {
      step('busca global');
      $$('.card')[0].classList.add('focus');
      key(403);
      assert.ok($$('.card')[0].classList.contains('isfav'), 'estrela aparece');
      // toque longo no segundo banner favorita
      var ev = new w.Event('touchstart', { bubbles: true });
      ev.touches = [{ clientX: 5, clientY: 5 }];
      $$('.card')[1].dispatchEvent(ev);
      return new Promise(function (r) { setTimeout(r, 800); });
    }).then(function () {
      assert.ok($$('.card')[1].classList.contains('isfav'), 'toque longo favorita');
      var ev2 = new w.Event('touchstart', { bubbles: true });
      ev2.touches = [{ clientX: 5, clientY: 5 }];
      $$('.card')[1].dispatchEvent(ev2);
      return new Promise(function (r) { setTimeout(r, 800); });
    }).then(function () {
      assert.ok(!$$('.card')[1].classList.contains('isfav'), 'toque longo desfavorita');
      step('toque longo');
      go('fav');
      return waitFor(function () { return $$('.card').length === 1; }, 'favoritos');
    }).then(function () {
      step('favoritos');
      $('.backbtn').click();
      return waitFor(function () { return $('.hubtab'); }, 'menu com favoritos');
    }).then(function () {
      var titles = $$('.hrow-title').map(function (t) { return t.textContent; });
      assert.ok(titles.indexOf('Favoritos') >= 0, 'com favoritos: fileira na home (' + titles.join(' | ') + ')');
      var row = $$('.hrow').filter(function (r) { return r.querySelector('.hrow-title').textContent === 'Favoritos'; })[0];
      assert.strictEqual(row.querySelectorAll('.card:not(.seeall)').length, 1, 'o favorito aparece na fileira');
      assert.ok(row.querySelector('.card.seeall'), 'Ver todos no fim da fileira');
      assert.ok(!$('.hub-links'), 'continua sem botão de atalho');
      row.querySelector('.card.seeall').click();
      return waitFor(function () { return $$('.card').length === 1 && $('.sectitle') && /Favoritos/.test($('.sectitle').textContent); }, 'ver todos abre a lista');
    }).then(function () {
      step('Favoritos na home como fileira (+ Ver todos), sem botão');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config');
    }).then(function () {
      var txt = $('.settings').textContent;
      assert.ok(/127\.0\.0\.1/.test(txt) && /joao/.test(txt));
      var ver = require('../app/appinfo.json').version;
      assert.ok(txt.indexOf('Versão do app') >= 0 && txt.indexOf(ver) >= 0, 'versão do app em Configurações deve ser a do appinfo.json (' + ver + ')');
      assert.strictEqual($$('.swrow').length, 3, 'três chaves');
      step('configurações');
      // ocultar SD / HD: a categoria "Filmes e séries 24h" tem Cine HD, Cine SD e Cine FHD
      $$('.swrow')[1].click(); // SD
      assert.ok($$('.sw')[1].classList.contains('on'));
      $$('.swrow')[2].click(); // HD
      $('.backbtn').click();
      go('live');
      return waitFor(function () { return $$('.cat').length === 4; }, 'ao vivo de novo');
    }).then(function () {
      $$('.cat')[3].click();
      return waitFor(function () { return $$('.row').length === 1; }, 'só o FHD sobra');
    }).then(function () {
      assert.ok(/Cine FHD/.test($('.row .name').textContent), 'FHD não é ocultado');
      step('ocultar canais SD e HD (FHD continua)');
      $('.backbtn').click();
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 2');
    }).then(function () {
      $$('.swrow')[1].click(); $$('.swrow')[2].click(); // desliga os dois
      // cidade do clima
      $('#city').value = 'Campinas';
      $('#city').focus();
      key(13);
      return waitFor(function () { return $$('.cityres .btn').length === 1; }, 'resultado da cidade');
    }).then(function () {
      assert.ok(/Campinas — São Paulo/.test($('.cityres .btn').textContent));
      $('.cityres .btn').click();
      assert.ok(/Campinas/.test($('.settings').textContent), 'cidade atualizada');
      $('.backbtn').click();
      return waitFor(function () { return $('.wx-c') && /Campinas/.test($('.wx-c').textContent); }, 'clima da nova cidade');
    }).then(function () {
      step('cidade do clima editável nas configurações');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 3');
    }).then(function () {
      // sincronização entre aparelhos (Worker simulado em http://127.0.0.1)
      var surl = 'http://127.0.0.1:' + syncSrv.address().port;
      assert.ok($('#syncurl') && $('#synccode'), 'bloco Sincronização nas configurações');
      $('#syncurl').value = surl;
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Gerar novo código'; })[0].click();
      return waitFor(function () { return Object.keys(syncKV).length === 1 && /Sincronizado/.test($('.settings').textContent); }, 'primeira sincronização');
    }).then(function () {
      var codeTxt = $('#synccode').value, stored = JSON.parse(syncKV[Object.keys(syncKV)[0]]);
      assert.ok(/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(codeTxt), 'código gerado: ' + codeTxt);
      assert.ok(Object.keys(stored.fav).length >= 1 && Object.keys(stored.cont).length >= 1, 'enviou favoritos e continuar assistindo');
      assert.ok(/Para parear outro aparelho, digite lá: .+#/.test($('.settings').textContent), 'mostra o texto de pareamento');
      // outro aparelho marca um favorito e assiste algo; este recebe ao sincronizar
      stored.fav['movie:777'] = { type: 'movie', id: '777', name: 'Filme do Celular' };
      stored.favmeta['movie:777'] = { at: Date.now() + 5000 };
      stored.cont['m:777'] = { rk: 'm:777', kind: 'movie', item: { type: 'movie', id: '777', name: 'Filme do Celular' }, t: 600, d: 6000, at: Date.now() + 5000 };
      stored.resume['m:777'] = { t: 600, d: 6000, at: Date.now() + 5000 };
      syncKV[Object.keys(syncKV)[0]] = JSON.stringify(stored);
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Sincronizar agora'; })[0].click();
      return waitFor(function () { return JSON.parse(w.localStorage.getItem('iptv.fav'))['movie:777']; }, 'favorito do outro aparelho chegou');
    }).then(function () {
      assert.ok(JSON.parse(w.localStorage.getItem('iptv.cont'))['m:777'], 'continuar assistindo do outro aparelho chegou');
      assert.ok(JSON.parse(w.localStorage.getItem('iptv.favmeta'))['movie:1'] || JSON.parse(w.localStorage.getItem('iptv.favmeta'))['movie:777'], 'favoritos têm data');
      step('sincronização: gerar código, enviar e receber do outro aparelho');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 4');
    }).then(function () {
      // estilo da Início: blocos grandes (padrão nas TVs) ou abas (padrão no celular)
      var btns = function (txt) { return $$('.settings .btn').filter(function (x) { return x.textContent === txt; })[0]; };
      assert.ok(btns('Abas no topo').classList.contains('primary'), 'aqui o padrão são as abas');
      btns('Blocos grandes').click();
      assert.strictEqual(w.localStorage.getItem('iptv.homestyle'), '"blocks"', 'escolha guardada neste aparelho');
      $('.backbtn').click();
      return waitFor(function () { return $$('.hubtile').length === 4; }, 'blocos grandes');
    }).then(function () {
      assert.deepStrictEqual($$('.hubname').map(function (e) { return e.textContent; }), ['TV ao vivo', 'Filmes', 'Séries', 'Esportes']);
      assert.ok(!$('.hubtab'), 'sem abas quando o estilo é blocos');
      $$('.hubtile')[1].click();
      return waitFor(function () { return $('.sectitle') && /Filmes/.test($('.sectitle').textContent); }, 'abre Filmes pelo bloco');
    }).then(function () {
      $('.backbtn').click();
      return waitFor(function () { return $$('.hubtile').length === 4 && $('.hubtile.focus'); }, 'volta aos blocos');
    }).then(function () {
      assert.strictEqual($('.hubtile.focus').getAttribute('data-sec'), 'movie', 'foco volta ao bloco de Filmes');
      step('estilo da Início: blocos grandes (e opção nas configurações)');
      $('.menubtn').click(); $('.drawer-settings').click();
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 5');
    }).then(function () {
      $$('.settings .btn').filter(function (x) { return x.textContent === 'Abas no topo'; })[0].click();
      $('.backbtn').click();
      return waitFor(function () { return $$('.hubtab').length === 4 && !$('.hubtile'); }, 'abas de novo');
    }).then(function () {
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 6');
    }).then(function () {
      // Esportes: placares (fonte simulada), canal pela programação, meus times, filtro de amistosos
      w.Sports.setBase(base + '/espn');
      go('home');
      assert.ok($('[data-sec="sports"]'), 'Esportes aparece na Início');
      return waitFor(function () { return $('.sphome .spcard'); }, 'jogos na Início');
    }).then(function () {
      var hx = $('.sphome').textContent;
      assert.ok(/jogos de hoje/.test(hx) && /Palmeiras/.test(hx) && /Flamengo/.test(hx) && !/Brazil/.test(hx), 'fileira de jogos na Início (sem jogos de outros dias): ' + hx.slice(0, 120));
      assert.ok($$('.sphome .spcard')[0].classList.contains('live'), 'jogo ao vivo vem primeiro');
      $$('.sphome .spcard')[0].click();
      assert.ok($('.spscoreboard') && /Raphael Veiga/.test($('.sports').textContent), 'toque no jogo da Início abre o jogo');
      // o canal é procurado na programação depois de abrir: quando aparece, o foco já fica nele (só dar OK)
      return waitFor(function () { return $('.spplay') && w.Nav.current() === $('.spplay'); }, 'foco no botão do canal');
    }).then(function () {
      key(27);
      return waitFor(function () { return $$('.spcard').length >= 1; }, 'placares');
    }).then(function () {
      var txt = $('.sports').textContent;
      assert.ok(/Ao vivo agora/.test(txt) && /AO VIVO 67'/.test(txt) && /Palmeiras/.test(txt) && /Grêmio/.test(txt), 'jogo ao vivo com minuto: ' + txt.slice(0, 160));
      assert.ok(/Flamengo/.test(txt) && !/France/.test(txt), 'amistoso sem o Brasil fica de fora');
      assert.ok(/Brasileirão/.test(txt), 'agrupa por liga');
      return waitFor(function () { return /Canal Esporte 2/.test($('.spcard.live').textContent); }, 'canal do jogo na programação');
    }).then(function () {
      assert.ok(!$('.spwarn'), 'uma liga fora do ar não polui a tela');
      $('.spcard.live').click();
      assert.ok(/Raphael Veiga/.test($('.sports').textContent) && /Posse de bola/.test($('.sports').textContent) && /55%/.test($('.sports').textContent), 'gols e estatísticas');
      var pl = $$('.spplay')[0];
      assert.ok(pl && /Canal Esporte 2/.test(pl.textContent), 'botão para assistir no canal');
      var fb = $$('.sports .btn').filter(function (b) { return /Seguir Palmeiras/.test(b.textContent); })[0];
      fb.click();
      assert.ok(/Seguindo Palmeiras/.test($('.sports').textContent) && JSON.parse(w.localStorage.getItem('iptv.sportteams'))['2029'], 'segue o time');
      key(27);
      assert.ok($('.spcard') && !$('.spback'), 'Voltar sai do jogo e volta à lista');
      assert.ok($('.spstar'), 'estrela no time seguido');
      $('.spcard.live').click();
      $$('.spplay')[0].click();
      assert.ok(!$('#player').classList.contains('hidden') && /103/.test($('#video').getAttribute('src')), 'assiste no canal: ' + $('#video').getAttribute('src'));
      key(413);
      assert.ok($('#player').classList.contains('hidden'));
      key(27);
      $('[data-k="tab:teams"]').click();
      assert.ok($('.spchip.team') && /Palmeiras/.test($('.sports').textContent), 'Meus times mostra o time e o jogo');
      $('[data-k="tab:channels"]').click();
      assert.ok(/Canal Esporte 2/.test($('.sports').textContent), 'aba de canais lista o jogo com o canal');
      $('[data-k="tab:scores"]').click();
      $('[data-k="d:2"]').click();
      assert.ok(/Brazil/.test($('.sports').textContent) && !/France/.test($('.sports').textContent), 'amistoso do Brasil aparece em outro dia');
      step('esportes: placares, canal pela programação, seguir time, amistosos só do Brasil');
      go('home');
      assert.ok($('.hubtab, .hubtile'));
      assert.ok(!$('.spchips'), 'saiu da tela de esportes');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 7');
    }).then(function () {
      // perfis: criar, trocar, dados separados
      var favs0 = w.localStorage.getItem('iptv.fav');
      assert.ok(favs0 && Object.keys(JSON.parse(favs0)).length >= 1, 'perfil 1 tem favoritos');
      assert.ok(/Perfil 1/.test($('.settings').textContent), 'mostra o perfil atual');
      $$('.settings .btn').filter(function (b) { return b.textContent === 'Gerenciar perfis'; })[0].click();
      assert.ok(!$('#profiles').classList.contains('hidden'), 'seletor de perfis abre');
      $('#profiles .padd').click();
      $('#profiles input').value = 'Ana';
      assert.ok($$('#profiles .aicon').length >= 12, 'editor oferece ícones de avatar');
      w.Nav.focus($$('#profiles .aicon')[2]);
      $$('#profiles .aicon')[2].click();
      assert.ok($$('#profiles .aicon')[2].classList.contains('on') && $('#profiles .pav svg'), 'ícone escolhido aparece no avatar');
      assert.strictEqual(w.Nav.current(), $$('#profiles .aicon')[2], 'o foco continua no ícone escolhido');
      $$('#profiles .btn').filter(function (b) { return b.textContent === 'Salvar'; })[0].click();
      assert.strictEqual($$('#profiles .pcard').length, 3, 'dois perfis + adicionar');
      assert.ok($$('#profiles .pcard')[1].querySelector('svg'), 'o perfil salvo mostra o ícone em vez da inicial');
      $$('#profiles .btn').filter(function (b) { return b.textContent === 'Concluído'; })[0].click();
      $$('#profiles .pcard')[1].click(); // entra no perfil Ana
      assert.ok($('#profiles').classList.contains('hidden') && $('.hubtab'), 'entrou no menu do novo perfil');
      assert.strictEqual(Object.keys(w.JSON.parse(w.localStorage.getItem('iptv.' + w.JSON.parse(w.localStorage.getItem('iptv.curprof')) + '.fav') || '{}')).length, 0, 'favoritos separados');
      assert.ok($('.avatar svg') && $('.avatar').textContent === '', 'avatar mostra o ícone escolhido no perfil');
      $('.avatar').click();
      $$('#profiles .pcard')[0].click(); // volta ao perfil 1
      assert.strictEqual(w.JSON.parse(w.localStorage.getItem('iptv.curprof')), 'p1');
      assert.strictEqual(w.localStorage.getItem('iptv.fav'), favs0, 'favoritos do perfil 1 intactos');
      step('perfis: criar, trocar e manter dados separados');
      go('settings');
      return waitFor(function () { return $('.settings .sgroup'); }, 'config 4');
    }).then(function () {
      // editar servidor: abre o login já preenchido, com Cancelar
      $$('.settings .btn')[0].click();
      return waitFor(function () { return $('.login'); }, 'editar servidor');
    }).then(function () {
      assert.strictEqual($$('.login input')[1].value, 'joao');
      assert.strictEqual($$('.login .btn').length, 2, 'Entrar + Cancelar');
      $$('.login .btn')[1].click(); // Cancelar
      return waitFor(function () { return $('.settings .sgroup'); }, 'volta às configurações');
    }).then(function () {
      step('editar servidor (preenchido, com cancelar)');
      $$('.settings .btn')[1].click(); // Trocar conta / Sair
      return waitFor(function () { return $('.login'); }, 'logout');
    }).then(function () {
      assert.strictEqual($$('.login input')[1].value, 'joao', 'logout mantém usuário');
      assert.strictEqual($$('.login .btn').length, 1, 'login sem modo demonstração');
      assert.ok(/MASTER IPTV/.test($('.login .logo').textContent));

      step('logout volta ao login (sem demonstração, nome Master IPTV)');
      // http x https: o servidor de teste só fala http; digitar https:// deve cair sozinho em http:// e guardar o que funcionou
      $$('.login input')[0].value = base.replace('http://', 'https://');
      $$('.login input')[2].value = 'segredo';
      $('.btn.primary').click();
      return waitFor(function () { return $('.hubtab, .hubtile'); }, 'login com https digitado');
    }).then(function () {
      assert.strictEqual(JSON.parse(w.localStorage.getItem('iptv.cfg')).server, base, 'guardou o endereço que funcionou (http)');
      assert.ok(/Servidor ajustado/.test($('#toast').textContent), 'avisa que ajustou o endereço');
      step('login: https digitado, servidor só http -> ajusta sozinho');
      return waitFor(function () {
        var c = JSON.parse(w.localStorage.getItem('iptv.spcache') || 'null');
        return c && Object.keys(c.days).length && Object.keys(c.chan).length && Object.keys(c.epg).length;
      }, 'jogos, canais e programação guardados no aparelho');
    }).then(function () {
      step('esportes: cache no aparelho (jogos, canais, programação)');
      assert.deepStrictEqual(errors, [], 'erros de script: ' + errors.join(' | '));
      console.log('UI ok');
    });
  });
}).then(function () { api.close(); px.close(); process.exit(0); }, function (e) {
  console.error('  FAIL ' + (e && e.stack || e)); try { console.error('  erros de página: ' + JSON.stringify(typeof errors !== 'undefined' ? errors : [])); } catch (x) {} process.exit(1);
});
